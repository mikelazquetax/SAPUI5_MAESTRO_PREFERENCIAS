sap.ui.define([
	"sap/ui/core/mvc/Controller",
	"sap/m/MessageBox",
	"sap/ui/model/Filter",
	"sap/ui/model/FilterOperator",
], function (Controller, MessageBox, Filter, FilterOperator) {
	"use strict";

	return Controller.extend("maz_renfe.maestro_preferencias_internas.controller.MainView", {
		onInit: function () {
			var that = this;
			//Funcion de carga de la Aplicación. Lo que hacemos es crear el JSONModel y traemos los datos de la BBDD HANA
			this.getView().getModel().read('/ZrcmpreferenciasinternasSet', {
				success: function (oData, response) {

					//ARRAY
					var datos = oData.results;
					//creacion de la carcasa del modelo
					var oModelNew = new sap.ui.model.json.JSONModel();
					//los datos en el modelo
					oModelNew.setData(datos);
					//append del modelo a la vista
					that.getView().setModel(oModelNew, "jsonPREF");

				},
				error: function (oError) {

				}

			});
		},

		onNewPlaza: function () {
			//Funcion que se ejecuta al pulsar el botón: Plaza Nueva
			var data = this.getView().getModel('jsonPREF').getData() //Array con los datos del modelo que esta bindeada a la tabla de nuestra vista
			var newLine = {
				"ID": "",
				"PLAZA": ""
			}
			var lastRecord = data.length

			if (lastRecord !== 0) {
				newLine.ID = (parseInt(data[lastRecord - 1].ID) + 1) // Obtenemos el nuevo ID
			} else {
				newLine.ID = (lastRecord + 1)
			}

			data.push(newLine)
			this.getView().getModel('jsonPREF').setData(data) //Puseamos nuestra nueva linea al modelo de la tabla. Todavia no se ha guardado en BBDD
		},

		onSave: function () {
			//Cuando pulsamos el botón guardar cogemos todos los datos que existen en el modelo jsonPREF de nuestra vista
			//y lo guardamos en el array data. Por cada iteracion de ese array, llamamos a una función asyncrona que es una promesa y que 
			//espera a la terminación de su ejecución para decidir en base a si el registro se encuentra en base de datos, crearlo o actualizarlo.
			//Si lo encuentra, lo actualiza. Si no, lo crea.
			var that = this
			var data = this.getView().getModel('jsonPREF').getData()

			var Arraydatos = []

			var Objectdatos = {
				"ID": "",
				"PLAZA": ""
			};

			data.forEach((datax) => {
				Objectdatos.ID = datax.ID.toString()
				Objectdatos.PLAZA = datax.PLAZA.toUpperCase().replaceAll("'", "-")

				Arraydatos.push(Objectdatos)
				Objectdatos = {
					"ID": "",
					"PLAZA": ""
				}
			});

			Arraydatos.forEach((dato) => {
					var that = this
					that.onRead(dato).then(function (apto) {
						if (apto == true) {
							that.onUpdate(dato)
						} else {
							that.onCreate(dato)
						}
					})
				})
				//			MessageBox.success('Registros Creados/Actualizados en Base de Datos')
		},

		onUpdate: function (dato) {

			var path = '/ZrcmpreferenciasinternasSet(' + parseFloat(dato.ID) + ')'
				//	var path = '/ZsociedadesSet(' + updatedRecord.ZID + ')';
			this.getView().getModel().update(path, dato, {
				success: function () {
					sap.m.MessageToast.show('Registros Actualizados')
				},
				error: function (oError) {

				}
			})

		},

		onCreate: function (dato) {
			dato.ID = dato.ID
			this.getView().getModel().create('/ZrcmpreferenciasinternasSet', dato, {
				success: function () {
					sap.m.MessageToast.show('Registros Actualizados')
				},
				error: function (oError) {
					console.log(dato)
				}
			})
		},

		onRead: async function (dato) {
			return new Promise((resolve, reject) => {

				this.getView().getModel().read('/ZrcmpreferenciasinternasSet', {
					filters: [
						new Filter("ID", "EQ", dato.ID)
					],
					success: function (oData, response) {
						var x = oData.results;
						if (x.length > 0) {
							resolve(true)
						} else {
							resolve(false)
						}
						/*					x.filter((x=>x.ID == dato.ID)) 
											if(x.filter((x=>x.ID == dato.ID)).length == 1)
											resolve(true)
											
											if(x.filter((x=>x.ID == dato.ID)).length == 0)
											resolve(false)*/
					},
					error: function (oError) {
						resolve(false)
					}
				})
			})

		},
		onDelete: function (evento) {
			var plazaEliminada = evento.getSource().getParent().getCells()[0].getText()
			var nombrePlaza = evento.getSource().getParent().getCells()[1].getValue()

			var that = this
				//			var pathx = "/ZrcmpreferenciasinternasSet(ID='" + plazaEliminada + "')"
			var pathx = '/ZrcmpreferenciasinternasSet(' + plazaEliminada + ')'
			var updatedData = []
			this.getView().getModel().remove(pathx, {
				method: 'DELETE',
				success: function () {
					MessageBox.success('Plaza Eliminada con Exito')
					var data = that.getView().getModel('jsonPREF').getData()
					data.forEach((x) => {
						if (x.PLAZA !== nombrePlaza)
							updatedData.push(x)
					})

					that.getView().getModel('jsonPREF').setData(updatedData)

				},
				error: function () {
					MessageBox.information('Registro no encontrado en Base de Datos. Se elimina unicamente de la vista')
					var data = that.getView().getModel('jsonPREF').getData()
					data.forEach((x) => {
						if (x.PLAZA !== nombrePlaza)
							updatedData.push(x)
					})
					that.getView().getModel('jsonPREF').setData(updatedData)

				}
			})
		}

	});
});