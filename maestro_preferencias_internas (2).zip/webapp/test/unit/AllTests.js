sap.ui.define([
	"maz_renfe/maestro_preferencias_internas/test/unit/controller/MainView.controller"
], function () {
	"use strict";
});