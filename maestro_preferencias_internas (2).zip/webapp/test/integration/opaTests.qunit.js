/* global QUnit */
QUnit.config.autostart = false;

sap.ui.getCore().attachInit(function () {
	"use strict";

	sap.ui.require([
		"maz_renfe/maestro_preferencias_internas/test/integration/AllJourneys"
	], function () {
		QUnit.start();
	});
});